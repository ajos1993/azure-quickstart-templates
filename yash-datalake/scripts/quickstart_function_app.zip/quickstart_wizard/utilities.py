import os
import json


import sys, os.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))
import requests
import pprint
import adal

## Use this only for Azure AD service-to-service authentication
from azure.common.credentials import ServicePrincipalCredentials

## Required for Azure Data Lake Analytics job management
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties

## Use these as needed for your application
import logging, getpass, pprint, uuid, time


def df_run_id(rest_url,app_id,app_secret,tenant):
    print(rest_url+'  '+app_id+'  '+app_secret+'  '+tenant)
    authority_url = 'https://login.microsoftonline.com/'+tenant
    context = adal.AuthenticationContext(authority_url)
    resource = 'https://management.azure.com/'
    
    token = context.acquire_token_with_client_credentials(resource, app_id, app_secret)
    headers ={'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    return_response = requests.post(rest_url, headers=headers)
    return return_response

def df_status(req_url,app_id,app_secret,tenant):
    print(req_url)
    authority_url = 'https://login.microsoftonline.com/'+tenant
    context = adal.AuthenticationContext(authority_url)
    resource = 'https://management.azure.com/'

    token = context.acquire_token_with_client_credentials(resource, app_id, app_secret)
    headers ={'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    return_response2 = requests.get(req_url,headers=headers)
    print('********'+str(return_response2))
    jsonresponse2 = return_response2.json()
    status = jsonresponse2['status']
    print(status)
    return status
    
def adla_run_job_status(jobId,adla,app_id,app_secret,tenant):
    credentials = ServicePrincipalCredentials(client_id = app_id, secret = app_secret, tenant = tenant)
    adlaJobClient = DataLakeAnalyticsJobManagementClient( credentials, 'azuredatalakeanalytics.net')
    jobResult = adlaJobClient.job.get(adla, jobId)
    print (jobResult)
    return jobResult

def run_stream_job(option,job_name,sub_id,rg_name,app_id,app_secret,tenant):
    authority_url = 'https://login.microsoftonline.com/'+tenant
    context = adal.AuthenticationContext(authority_url)
    resource = 'https://management.azure.com/'

    token = context.acquire_token_with_client_credentials(resource, app_id, app_secret)

    url = "https://management.azure.com/subscriptions/"+sub_id+"/resourceGroups/"+rg_name+"/providers/Microsoft.StreamAnalytics/streamingjobs/"+job_name+"/"+option
    print url
    print token['accessToken']
    querystring = {"api-version":"2015-10-01"}

    headers ={'Authorization': 'Bearer ' + token['accessToken'],
            'content-type': "application/atom+xml;type=entry;charset=utf-8",
            'x-ms-retrypolicy': "NoRetry"
    }

    response = requests.request("POST", url, headers=headers, params=querystring)
    print(response.text)